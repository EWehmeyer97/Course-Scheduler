require "application_system_test_case"

class RecommandsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit recommands_url
  #
  #   assert_selector "h1", text: "Recommand"
  # end
end
