class StaticPagesController < ApplicationController

  def home
  end
  def signup_job

  end
  def login

  end
  def login_student

  end
  def login_professer

  end
  def login_admin

  end
end
