require 'test_helper'

class ProfesserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
