require "application_system_test_case"

class SectionsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit sections_url
  #
  #   assert_selector "h1", text: "Section"
  # end
end
