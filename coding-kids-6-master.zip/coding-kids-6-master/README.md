# coding-kids-6
#README for Project 6 - Deployment version

#Authors
Elen DeWitt
Jackie Greene
Weilie Lin
Vicky Sandanoval
Evan Wehmeyer

#Project Description
This is the v2 for the Final Project for CSE 3901. THis project centers around using a ruby on rails project to redesign the CSE Grader Application and Assignment webpage for the CSE department.

#Instructions on how to run the project downloaded from git
	1) Enter the final_base directory
	2) run bundle install
	3) run rails db:migrate
	4) run rails server
	5) open firefox and got to localhost:3000

#Instructions on how to run the project on heroku
	Go to this link: https://coding-kids-final.herokuapp.com

#Functionality Notes
	An Admin must add a course section prior to a student applying for any courses

	An Admin needs to be the first user created

