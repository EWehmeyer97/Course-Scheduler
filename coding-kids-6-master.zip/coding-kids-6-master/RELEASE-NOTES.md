#REALEASE-NOTES for Project 6 - Deployment version

#Authors
Elen DeWitt
Jackie Greene
Weilie Lin
Vicky Sandanoval
Evan Wehmeyer

#Functionality Implemented for v1 (Beta release)
	All critical features are implemented for this project. For the application preference section we worked under the assumption that graders would only list classes that they wanted to grade for so no direct preference rankning is needed but could be added for v2.


#Functionality for v2
	Add login and logout validations 
	Check Password Hashing and redirect for incorrect passwords
	Added styling and pre-fill for forms
	Added a logout button and streamlined the style of the application