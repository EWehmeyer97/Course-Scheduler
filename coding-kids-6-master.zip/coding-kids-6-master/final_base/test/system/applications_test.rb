require "application_system_test_case"

class ApplicationsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit applications_url
  #
  #   assert_selector "h1", text: "Application"
  # end
end
