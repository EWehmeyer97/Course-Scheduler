require "application_system_test_case"

class ProfessersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit professers_url
  #
  #   assert_selector "h1", text: "Professer"
  # end
end
