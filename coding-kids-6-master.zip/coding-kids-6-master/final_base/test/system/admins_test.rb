require "application_system_test_case"

class AdminsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit admins_url
  #
  #   assert_selector "h1", text: "Admin"
  # end
end
