require 'test_helper'

class RecommandTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
